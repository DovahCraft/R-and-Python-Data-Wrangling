library(testthat)
library(VargovichFlagstaffWeather)

test_check("VargovichFlagstaffWeather")
